from PyQt5 import QtCore, QtWidgets
from PyQt5.QtWidgets import QApplication,  QLineEdit , QWidget ,QFormLayout,QPushButton,QMainWindow
from one import Ui_Form1
from two import Ui_MainWindow
import sys 
import winsound


if __name__ == '__main__':
	app = QApplication(sys.argv)
	main = QWidget()
	main_ui = Ui_Form1()
	main_ui.setupUi_1(main)
	#实例化子窗口
	child = QMainWindow()
	child_ui = Ui_MainWindow()
	child_ui.setupUi_2(child)
	#按钮绑定事件
	btn = main_ui.pushButton_2
	btn.clicked.connect(child.show)
	#显示
	main.show()
	sys.exit(app.exec_())
