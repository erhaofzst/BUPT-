# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'one.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import QCoreApplication
import winsound
from two import Ui_MainWindow


class Ui_Form1(object):
    def setupUi_1(self, Form):
        Form.setObjectName("Form")
        Form.resize(238, 300)
        self.pushButton = QtWidgets.QPushButton(Form)
        self.pushButton.setGeometry(QtCore.QRect(0, -1, 81, 361))
        self.pushButton.setStyleSheet("background-color:#FFFFFF")
        self.pushButton.setObjectName("pushButton")
        self.pushButton_2 = QtWidgets.QPushButton(Form)
        self.pushButton_2.setGeometry(QtCore.QRect(80, 0, 81, 361))
        self.pushButton_2.setStyleSheet("background-color:#FFFFFF")
        self.pushButton_2.setObjectName("pushButton_2")
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(50, 0, 41, 166))
        self.label.setStyleSheet("background-color:#000000")
        self.label.setObjectName("label")
        self.pushButton_3 = QtWidgets.QPushButton(Form)
        self.pushButton_3.setGeometry(QtCore.QRect(160, 0, 81, 361))
        self.pushButton_3.setStyleSheet("background-color:#FFFFFF")
        self.pushButton_3.setObjectName("pushButton_3")
        self.label_2 = QtWidgets.QLabel(Form)
        self.label_2.setGeometry(QtCore.QRect(150, 0, 41, 166))
        self.label_2.setStyleSheet("background-color:#000000")
        self.label_2.setObjectName("label_2")

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

        self.pushButton.clicked.connect(self.on_click_1)
        self.pushButton_3.clicked.connect(self.on_click_3)


    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.pushButton.setText(_translate("Form", "听听升音"))
        self.pushButton_2.setText(_translate("Form", "你来弹吧"))
        self.label.setText(_translate("Form", "TextLabel"))
        self.pushButton_3.setText(_translate("Form", "生日快乐"))
        self.label_2.setText(_translate("Form", "TextLabel"))


    def on_click_1(self):
        x = 100
        while x <= 2000:
            winsound.Beep(x,500)
            x = x + 100

    def on_click_3(self):
        
        kuaile1 = [784,784,880,784,1046,988,784,784,880,784,1175,1046,784,784,1568,1318,1046,988,880,1397,1397,1318,1046,1175,1046]
        for yin in kuaile1:
            winsound.Beep(yin,500)
