# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'two.ui'
#
# Created by: PyQt5 UI code generator 5.13.2
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import winsound

suit = {'1DO':262, '1DO#':277, '1RE':294, '1RE#':311, '1MI':330, '1FA':349, '1FA#':370, '1SO':392, '1SO#':415, '1LA':440, '1LA#':466, '1SI':494, '2DO':523, '2DO#':554, '2RE':587, '2RE#':622, '2MI':659, '2FA':698, '2FA#':740, '2SO':784, '2SO#':831, '2LA':880, '2LA#':932, '2SI':988, '3DO':1046, '3DO#':1109, '3RE':1175, '3RE#':1245, '3MI':1318, '3FA':1397, '3FA#':1480, '3SO':1568, '3SO#':1661, '3LA':1760, '3LA#':1865, '3SI':1976}

Astr = ""


class Ui_MainWindow(object):
    def setupUi_2(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(499, 470)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton.setGeometry(QtCore.QRect(0, 320, 501, 100))
        self.pushButton.setStyleSheet("background-color:#FFFFFF")
        self.pushButton.setObjectName("pushButton")
        self.textEdit = QtWidgets.QTextEdit(self.centralwidget)
        self.textEdit.setGeometry(QtCore.QRect(0, 239, 511, 81))
        self.textEdit.setObjectName("textEdit")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(0, 120, 501, 120))
        self.label.setStyleSheet("background-color:#FFFFFF")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(0, 0, 501, 120))
        self.label_2.setStyleSheet("background-color:#FFFFFF")
        self.label_2.setObjectName("label_2")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(150, 70, 351, 41))
        self.label_3.setStyleSheet("background-color:#000000")
        self.label_3.setText("")
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(150, 190, 351, 41))
        self.label_4.setStyleSheet("background-color:#000000")
        self.label_4.setText("")
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(150, 320, 351, 41))
        self.label_5.setStyleSheet("background-color:#000000")
        self.label_5.setText("")
        self.label_5.setObjectName("label_5")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 499, 26))
        self.menubar.setObjectName("menubar")
        self.menu = QtWidgets.QMenu(self.menubar)
        self.menu.setObjectName("menu")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.menubar.addAction(self.menu.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

        self.pushButton.clicked.connect(self.yanzou)


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "MainWindow"))
        self.pushButton.setText(_translate("MainWindow", "开始演奏吧~"))
        self.label.setText(_translate("MainWindow", "0.5s的低音DO，请打0.51DO，0.7s的高音DO，请打0.73DO"))
        self.label_2.setText(_translate("MainWindow", "请输入你想弹的音~，请用空格隔开~"))
        self.menu.setTitle(_translate("MainWindow", "弹奏"))

    
    def yanzou(self):
        x = 0
        k = 0
        i = []
    #提取字符串，并处理字符串
        Astr = self.textEdit.toPlainText()
        lenth = len(Astr)
        while x <= lenth - 1:
            if Astr[x] == ' ':
                i.append(x)
            
            x = x + 1
        
        biao = []
        p = ''
        a = 0
        b = 0
        while a <= len(i) - 1:
            while b <= i[a]:
                p = p + Astr[b]
                b = b + 1

            biao.append(p)
            p = ''
            a = a + 1
        
        while b <=  lenth - 1:
            p = p + Astr[b]
            b = b + 1
        biao.append(p)
        p = ''

        e = 0
        real = []
        while e <= len(biao) - 2:
            real.append(biao[e][:-1])
            e = e + 1

        real.append(biao[-1])
        
        for yin in real:
            y = float(yin[0:3])
            y = y*1000
            winsound.Beep(suit[yin[3:]],int(y))